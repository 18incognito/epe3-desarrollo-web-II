<?php 
// Incluye el archivo global.php, que debería definir constantes para la conexión a la base de datos
require_once "global.php";

// Crea una nueva conexión a la base de datos utilizando los parámetros definidos en global.php
$conexion = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Configura el conjunto de caracteres para la conexión
mysqli_query($conexion, 'SET NAMES "' . DB_ENCODE . '"');

// Verifica si hubo un error al intentar conectar con la base de datos
if (mysqli_connect_errno()) {
    // Muestra un mensaje de error en caso de falla en la conexión
    printf("Falló en la conexión con la base de datos: %s\n", mysqli_connect_error());
    // Termina la ejecución del script
    exit();
}

// Verifica si la función 'ejecutarConsulta' no existe para definirla
if (!function_exists('ejecutarConsulta')) {
    // Define la función 'ejecutarConsulta' que ejecuta una consulta SQL
    function ejecutarConsulta($sql) {
        global $conexion;
        // Ejecuta la consulta SQL y devuelve el resultado
        $query = $conexion->query($sql);
        return $query;
    }

    // Define la función 'ejecutarConsultaSimpleFila' que ejecuta una consulta SQL y devuelve una fila asociativa
    function ejecutarConsultaSimpleFila($sql) {
        global $conexion;
        // Ejecuta la consulta SQL
        $query = $conexion->query($sql);
        // Obtiene una fila asociativa del resultado y la devuelve
        $row = $query->fetch_assoc();
        return $row;
    }

    // Define la función 'ejecutarConsulta_retornarID' que ejecuta una consulta SQL y devuelve el ID del último registro insertado
    function ejecutarConsulta_retornarID($sql) {
        global $conexion;
        // Ejecuta la consulta SQL
        $query = $conexion->query($sql);
        // Devuelve el ID del último registro insertado
        return $conexion->insert_id;
    }

    // Define la función 'limpiarCadena' que limpia una cadena de texto para prevenir inyecciones SQL y XSS
    function limpiarCadena($str) {
        global $conexion;
        // Escapa caracteres especiales para la consulta SQL
        $str = mysqli_real_escape_string($conexion, trim($str));
        // Convierte caracteres especiales en entidades HTML para prevenir XSS
        return htmlspecialchars($str);
    }
}
?>