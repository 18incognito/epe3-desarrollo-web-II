<?php 
// Incluye el archivo que contiene la clase Asistencia
require_once "../modelos/Asistencia.php";

// Inicia una sesión si no está iniciada
if (strlen(session_id())<1)  
    session_start(); 

// Crea una instancia de la clase Asistencia
$asistencia = new Asistencia();

// Recoge los datos enviados a través de POST y los limpia
$id = isset($_POST["idasistencia"]) ? limpiarCadena($_POST["idasistencia"]) : "";
$kind_id = isset($_POST["tipo_asistencia"]) ? limpiarCadena($_POST["tipo_asistencia"]) : "";
$date_at = isset($_POST["fecha_asistencia"]) ? limpiarCadena($_POST["fecha_asistencia"]) : "";
$alumn_id = isset($_POST["alumn_id"]) ? limpiarCadena($_POST["alumn_id"]) : "";
$team_id = isset($_POST["idgrupo"]) ? limpiarCadena($_POST["idgrupo"]) : "";
$user_id = $_SESSION["idusuario"];

// Ejecuta una acción basada en el parámetro 'op' enviado a través de GET
switch ($_GET["op"]) {
    case 'guardaryeditar':
        // Si el ID está vacío, se realiza una inserción; de lo contrario, se actualiza
        if (empty($id)) {
            // Llama al método insertar de la clase Asistencia
            $rspta = $asistencia->insertar($kind_id, $date_at, $alumn_id, $team_id); 
            // Devuelve un mensaje según el resultado de la inserción
            echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
        } else {
            // Llama al método editar de la clase Asistencia
            $rspta = $asistencia->editar($id, $kind_id, $date_at, $alumn_id, $team_id);
            // Devuelve un mensaje según el resultado de la actualización
            echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos"; 
        }
        break;
    
    case 'desactivar':
        // Llama al método desactivar de la clase Asistencia
        $rspta = $asistencia->desactivar($id);
        // Devuelve un mensaje según el resultado de la desactivación
        echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
        break;

    case 'activar':
        // Llama al método activar de la clase Asistencia
        $rspta = $asistencia->activar($id);
        // Devuelve un mensaje según el resultado de la activación
        echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
        break;
    
    case 'mostrar':
        // Llama al método mostrar de la clase Asistencia y devuelve los datos en formato JSON
        $rspta = $asistencia->mostrar($id);
        echo json_encode($rspta);
        break;

    case 'verificar':
        // Llama al método verificar de la clase Asistencia y devuelve los datos en formato JSON
        $rspta = $asistencia->verificar($date_at, $alumn_id, $team_id);
        echo json_encode($rspta);
        break;

    case 'listar':
        // Incluye el archivo que contiene la clase Alumnos
        require_once "../modelos/Alumnos.php";
        // Crea una instancia de la clase Alumnos
        $alumnos = new Alumnos();
        // Recoge el ID del grupo enviado a través de REQUEST
        $team_id = $_REQUEST["idgrupo"];
        // Llama al método listar de la clase Alumnos
        $rspta = $alumnos->listar($user_id, $team_id);
        $data = array();

        // Itera sobre los registros devueltos por el método listar
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                // Agrega botones de acción dependiendo del estado del registro
                "0" => ($reg->is_active)
                    ? '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->id . ')"><i class="fa fa-pencil"></i></button>'
                      . ' ' . '<button class="btn btn-warning btn-xs" onclick="mostrar_precios(' . $reg->id . ')">P</i></button>'
                      . ' ' . '<button class="btn btn-danger btn-xs" onclick="desactivar(' . $reg->id . ')"><i class="fa fa-close"></i></button>'
                    : '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->id . ')"><i class="fa fa-pencil"></i></button>'
                      . '<button class="btn btn-warning btn-xs" onclick="mostrar_precios(' . $reg->id . ')">P</i></button>'
                      . ' ' . '<button class="btn btn-primary btn-xs" onclick="activar(' . $reg->id . ')"><i class="fa fa-check"></i></button>',
                // Muestra la imagen del alumno
                "1" => "<img src='../files/articulos/" . $reg->image . "' height='50px' width='50px'>",
                // Muestra el nombre del alumno
                "2" => $reg->name,
                // Muestra el apellido del alumno
                "3" => $reg->lastname,
                // Muestra el teléfono del alumno
                "4" => $reg->phone,
                // Muestra un botón para marcar la asistencia
                "5" => '<button class="btn btn-info btn-xs" onclick="verificar(' . $reg->id . ')"><i class="fa fa-check"></i> Marcar</button>'
            );
        }

        // Prepara los datos para el datatable
        $results = array(
            "sEcho" => 1, // Información para datatables
            "iTotalRecords" => count($data), // Envia el total de registros al datatable
            "iTotalDisplayRecords" => count($data), // Envia el total de registros a visualizar
            "aaData" => $data // Datos para visualizar
        );

        // Devuelve los datos en formato JSON
        echo json_encode($results);
        break;
}
?>