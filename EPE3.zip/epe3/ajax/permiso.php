<?php 
// Incluye el archivo que define la clase Permiso
require_once "../modelos/Permiso.php";

// Crea una instancia de la clase Permiso
$categoria = new Permiso();

// Maneja la solicitud según el valor del parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    
    case 'listar':
        // Llama al método listar de la clase Permiso para obtener todos los permisos
        $rspta = $categoria->listar();
        $data = Array();

        // Recorre los resultados obtenidos y construye el array de datos
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                // Agrega el nombre del permiso al array de datos
                "0" => $reg->nombre
            );
        }

        // Prepara los datos para el DataTable y devuelve los resultados en formato JSON
        $results = array(
            "sEcho" => 1, // Información para DataTables
            "iTotalRecords" => count($data), // Enviamos el total de registros al DataTable
            "iTotalDisplayRecords" => count($data), // Enviamos el total de registros a visualizar
            "aaData" => $data // Datos a mostrar en la tabla
        );
        echo json_encode($results); // Devuelve los datos en formato JSON
        break;
}
?>