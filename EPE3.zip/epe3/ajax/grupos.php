<?php 
// Incluye el archivo que define la clase Grupos
require_once "../modelos/Grupos.php";

// Inicia una nueva sesión si no hay una sesión activa
if (strlen(session_id()) < 1) 
    session_start();

// Crea una instancia de la clase Grupos
$grupos = new Grupos();

// Obtiene los datos enviados mediante POST y los limpia usando la función limpiarCadena
$idgrupo = isset($_POST["idgrupo"]) ? limpiarCadena($_POST["idgrupo"]) : "";
$idusuario = $_SESSION["idusuario"]; // Obtiene el ID del usuario de la sesión
$nombre = isset($_POST["nombre"]) ? limpiarCadena($_POST["nombre"]) : "";
$favorito = isset($_POST["favorito"]) ? 1 : 0; // Marca si el grupo es favorito (1) o no (0)

// Maneja las diferentes operaciones según el parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    
    case 'guardaryeditar':
        if (empty($idgrupo)) {
            // Si no se proporciona un ID de grupo (es decir, es una inserción), llama al método insertar
            $rspta = $grupos->insertar($nombre, $favorito, $idusuario);
            // Devuelve un mensaje de éxito o error
            echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
        } else {
            // Si se proporciona un ID de grupo (es decir, es una actualización), llama al método editar
            $rspta = $grupos->editar($idgrupo, $nombre, $favorito, $idusuario);
            // Devuelve un mensaje de éxito o error
            echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
        }
        break;
    
    case 'anular':
        // Llama al método anular para desactivar un grupo usando su ID
        $rspta = $grupos->anular($idgrupo);
        // Devuelve un mensaje de éxito o error
        echo $rspta ? "Ingreso anulado correctamente" : "No se pudo anular el ingreso";
        break;
    
    case 'mostrar':
        // Llama al método mostrar para obtener los detalles de un grupo usando su ID
        $rspta = $grupos->mostrar($idgrupo);
        // Devuelve los datos en formato JSON
        echo json_encode($rspta);
        break;

    case 'listar':
        // Llama al método listar para obtener todos los grupos
        $rspta = $grupos->listar();
        $data = Array();

        // Recorre los resultados y construye el array de datos para la tabla
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                "0" => '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->idgrupo . ')"><i class="fa fa-pencil"></i></button>' . ' ' . '<button class="btn btn-danger btn-xs" onclick="anular(' . $reg->idgrupo . ')"><i class="fa fa-close"></i></button>',
                "1" => $reg->nombre,
                "2" => $reg->usuario
            );
        }

        // Prepara los datos para el DataTable y devuelve los resultados en formato JSON
        $results = array(
            "sEcho" => 1, // Información para DataTables
            "iTotalRecords" => count($data), // Enviamos el total de registros al DataTable
            "iTotalDisplayRecords" => count($data), // Enviamos el total de registros a visualizar
            "aaData" => $data
        );
        echo json_encode($results);
        break;
}
?>