<?php 
// Inicia una nueva sesión o reanuda la sesión actual
session_start();

// Incluye el archivo que define la clase Usuario
require_once "../modelos/Usuario.php";

// Crea una instancia de la clase Usuario
$usuario = new Usuario();

// Obtiene los datos enviados por POST y los limpia
$idusuarioc = isset($_POST["idusuarioc"]) ? limpiarCadena($_POST["idusuarioc"]) : "";
$clavec = isset($_POST["clavec"]) ? limpiarCadena($_POST["clavec"]) : "";
$idusuario = isset($_POST["idusuario"]) ? limpiarCadena($_POST["idusuario"]) : "";
$nombre = isset($_POST["nombre"]) ? limpiarCadena($_POST["nombre"]) : "";
$tipo_documento = isset($_POST["tipo_documento"]) ? limpiarCadena($_POST["tipo_documento"]) : "";
$num_documento = isset($_POST["num_documento"]) ? limpiarCadena($_POST["num_documento"]) : "";
$direccion = isset($_POST["direccion"]) ? limpiarCadena($_POST["direccion"]) : "";
$telefono = isset($_POST["telefono"]) ? limpiarCadena($_POST["telefono"]) : "";
$email = isset($_POST["email"]) ? limpiarCadena($_POST["email"]) : "";
$cargo = isset($_POST["cargo"]) ? limpiarCadena($_POST["cargo"]) : "";
$login = isset($_POST["login"]) ? limpiarCadena($_POST["login"]) : "";
$clave = isset($_POST["clave"]) ? limpiarCadena($_POST["clave"]) : "";
$imagen = isset($_POST["imagen"]) ? limpiarCadena($_POST["imagen"]) : "";

// Maneja la solicitud según el valor del parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    
    case 'guardaryeditar':
        // Verifica si se ha subido una imagen
        if (!file_exists($_FILES['imagen']['tmp_name']) || !is_uploaded_file($_FILES['imagen']['tmp_name'])) {
            // Si no hay una nueva imagen, mantiene la imagen actual
            $imagen = $_POST["imagenactual"];
        } else {
            // Si se ha subido una imagen nueva, procesa la imagen
            $ext = explode(".", $_FILES["imagen"]["name"]);
            if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/png") {
                $imagen = round(microtime(true)) . '.' . end($ext);
                move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/usuarios/" . $imagen);
            }
        }

        // Hash SHA256 para la contraseña
        $clavehash = hash("SHA256", $clave);

        // Si no hay un ID de usuario, se inserta un nuevo usuario
        if (empty($idusuario)) {
            $rspta = $usuario->insertar($nombre, $tipo_documento, $num_documento, $direccion, $telefono, $email, $cargo, $login, $clavehash, $imagen, $_POST['permiso']);
            echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar todos los datos del usuario";
        } else {
            // Si hay un ID de usuario, se actualiza el usuario existente
            $rspta = $usuario->editar($idusuario, $nombre, $tipo_documento, $num_documento, $direccion, $telefono, $email, $cargo, $login, $imagen, $_POST['permiso']);
            echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
        }
        break;
    
    case 'desactivar':
        // Desactiva el usuario con el ID dado
        $rspta = $usuario->desactivar($idusuario);
        echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
        break;

    case 'activar':
        // Activa el usuario con el ID dado
        $rspta = $usuario->activar($idusuario);
        echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
        break;
    
    case 'mostrar':
        // Muestra los datos del usuario con el ID dado
        $rspta = $usuario->mostrar($idusuario);
        echo json_encode($rspta);
        break;

    case 'editar_clave':
        // Hash SHA256 para la nueva contraseña
        $clavehash = hash("SHA256", $clavec);
        // Actualiza la contraseña del usuario con el ID dado
        $rspta = $usuario->editar_clave($idusuarioc, $clavehash);
        echo $rspta ? "Password actualizado correctamente" : "No se pudo actualizar el password";
        break;

    case 'mostrar_clave':
        // Muestra la clave del usuario con el ID dado
        $rspta = $usuario->mostrar_clave($idusuario);
        echo json_encode($rspta);
        break;
    
    case 'listar':
        // Lista todos los usuarios
        $rspta = $usuario->listar();
        // Declara un array para almacenar los datos
        $data = Array();

        // Recorre los resultados obtenidos y construye el array de datos
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                "0" => ($reg->condicion) 
                    ? '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->idusuario . ')"><i class="fa fa-pencil"></i></button> ' . 
                      '<button class="btn btn-info btn-xs" onclick="mostrar_clave(' . $reg->idusuario . ')"><i class="fa fa-key"></i></button> ' . 
                      '<button class="btn btn-danger btn-xs" onclick="desactivar(' . $reg->idusuario . ')"><i class="fa fa-close"></i></button>'
                    : '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->idusuario . ')"><i class="fa fa-pencil"></i></button> ' . 
                      '<button class="btn btn-info btn-xs" onclick="mostrar_clave(' . $reg->idusuario . ')"><i class="fa fa-key"></i></button> ' . 
                      '<button class="btn btn-primary btn-xs" onclick="activar(' . $reg->idusuario . ')"><i class="fa fa-check"></i></button>',
                "1" => $reg->nombre,
                "2" => $reg->tipo_documento,
                "3" => $reg->num_documento,
                "4" => $reg->telefono,
                "5" => $reg->email,
                "6" => $reg->login,
                "7" => "<img src='../files/usuarios/" . $reg->imagen . "' height='50px' width='50px'>",
                "8" => ($reg->condicion) ? '<span class="label bg-green">Activado</span>' : '<span class="label bg-red">Desactivado</span>'
            );
        }

        // Prepara los datos para el DataTable y devuelve los resultados en formato JSON
        $results = array(
            "sEcho" => 1, // Información para DataTables
            "iTotalRecords" => count($data), // Total de registros
            "iTotalDisplayRecords" => count($data), // Total de registros a visualizar
            "aaData" => $data // Datos a mostrar en la tabla
        );
        echo json_encode($results);
        break;

    case 'permisos':
        // Incluye el archivo que define la clase Permiso
        require_once "../modelos/Permiso.php";
        $permiso = new Permiso();
        // Obtiene todos los permisos
        $rspta = $permiso->listar();

        // Obtiene los permisos asignados al usuario con el ID dado
        $id = $_GET['id'];
        $marcados = $usuario->listarmarcados($id);
        // Declara el array para almacenar los permisos asignados
        $valores = array();

        // Almacena los permisos asignados
        while ($per = $marcados->fetch_object()) {
            array_push($valores, $per->idpermiso);
        }

        // Muestra la lista de permisos con checkboxes
        while ($reg = $rspta->fetch_object()) {
            $sw = in_array($reg->idpermiso, $valores) ? 'checked' : '';
            echo '<li><input type="checkbox" ' . $sw . ' name="permiso[]" value="' . $reg->idpermiso . '">' . $reg->nombre . '</li>';
        }
        break;

    case 'verificar':
        // Valida si el usuario tiene acceso al sistema
        $logina = $_POST['logina'];
        $clavea = $_POST['clavea'];

        // Hash SHA256 para la contraseña
        $clavehash = hash("SHA256", $clavea);
    
        // Verifica el login y la contraseña
        $rspta = $usuario->verificar($logina, $clavehash);

        $fetch = $rspta->fetch_object();

        if (isset($fetch)) {
            // Declara las variables de sesión
            $_SESSION['idusuario'] = $fetch->idusuario;
            $_SESSION['nombre'] = $fetch->nombre;
            $_SESSION['imagen'] = $fetch->imagen;
            $_SESSION['login'] = $fetch->login;
            $_SESSION['cargo'] = $fetch->cargo;

            // Obtiene los permisos del usuario
            $marcados = $usuario->listarmarcados($fetch->idusuario);
            // Declara el array para almacenar todos los permisos
            $valores = array();

            // Almacena los permisos asignados en el array
            while ($per = $marcados->fetch_object()) {
                array_push($valores, $per->idpermiso);
            }

            // Determina los accesos del usuario
            $_SESSION['escritorio'] = in_array(1, $valores) ? 1 : 0;
            $_SESSION['grupos'] = in_array(2, $valores) ? 1 : 0;
            $_SESSION['acceso'] = in_array(3, $valores) ? 1 : 0;
        }
        echo json_encode($fetch);
        break;

    case 'salir':
        // Limpia las variables de sesión
        session_unset();
        // Destruye la sesión
        session_destroy();
        // Redirecciona al login
        header("Location: ../index.php");
        break;
}
?>