<?php 
// Incluye el archivo que define la clase Cursos
require_once "../modelos/Cursos.php";

// Crea una instancia de la clase Cursos
$cursos = new Cursos();

// Recupera los datos enviados mediante POST, usando una función para limpiar las cadenas
$id = isset($_POST["idcurso"]) ? limpiarCadena($_POST["idcurso"]) : "";
$name = isset($_POST["nombre"]) ? limpiarCadena($_POST["nombre"]) : "";
$team_id = isset($_POST["idgrupo"]) ? limpiarCadena($_POST["idgrupo"]) : "";

// Maneja las diferentes operaciones según el parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    
    case 'guardaryeditar':
        if (empty($id)) {
            // Si no se ha proporcionado un ID (es decir, es una inserción), llama al método insertar
            $rspta = $cursos->insertar($name, $team_id);
            echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
        } else {
            // Si se ha proporcionado un ID (es decir, es una actualización), llama al método editar
            $rspta = $cursos->editar($id, $name, $team_id);
            echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
        }
        break;
    
    case 'desactivar':
        // Llama al método desactivar para desactivar un curso usando su ID
        $rspta = $cursos->desactivar($id);
        echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
        break;
    
    case 'activar':
        // Llama al método activar para activar un curso usando su ID
        $rspta = $cursos->activar($id);
        echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
        break;
    
    case 'mostrar':
        // Llama al método mostrar para obtener los detalles de un curso usando su ID
        $rspta = $cursos->mostrar($id);
        // Devuelve los datos en formato JSON
        echo json_encode($rspta);
        break;
    
    case 'listar':
        // Recupera el ID del grupo enviado mediante REQUEST
        $team_id = $_REQUEST["idgrupo"];
        // Llama al método listar para obtener la lista de cursos para el grupo
        $rspta = $cursos->listar($team_id);
        
        $data = Array();

        // Recorre los resultados y construye el array de datos para la tabla
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                "0" => '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->id . ')"><i class="fa fa-pencil"></i></button>' . ' ' . '<button class="btn btn-danger btn-xs" onclick="desactivar(' . $reg->id . ')"><i class="fa fa-close"></i></button>',
                "1" => $reg->name
            );
        }
        
        // Prepara los datos para el DataTable y devuelve los resultados en formato JSON
        $results = array(
            "sEcho" => 1, // Información para DataTables
            "iTotalRecords" => count($data), // Enviamos el total de registros al DataTable
            "iTotalDisplayRecords" => count($data), // Enviamos el total de registros a visualizar
            "aaData" => $data
        );
        echo json_encode($results);
        break;
    
    case 'selectCursos':
        // Recupera el ID del grupo enviado mediante REQUEST
        $team_id = $_REQUEST["idgrupo"];
        // Llama al método listar para obtener la lista de cursos para el grupo
        $rspta = $cursos->listar($team_id);
        
        // Construye las opciones para un elemento <select>
        echo '<option value="0">seleccione...</option>';
        while ($reg = $rspta->fetch_object()) {
            echo '<option value=' . $reg->id . '>' . $reg->name . '</option>';
        }
        break;
}
?>