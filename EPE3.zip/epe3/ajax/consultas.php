<?php 
// Incluye el archivo que define la clase Consultas
require_once "../modelos/Consultas.php";

// Inicia una sesión si no ha sido iniciada
if (strlen(session_id()) < 1) 
    session_start();

// Crea una instancia de la clase Consultas
$consulta = new Consultas();

// Obtiene el ID del usuario actual desde la sesión
$user_id = $_SESSION["idusuario"];

// Maneja las diferentes operaciones según el parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    
    case 'lista_asistencia':
        // Recupera las fechas y el ID del grupo enviados mediante REQUEST
        $fecha_inicio = $_REQUEST["fecha_inicio"];
        $fecha_fin = $_REQUEST["fecha_fin"];
        $team_id = $_REQUEST["idgrupo"];

        // Calcula el rango de fechas
        $range = 0;
        if ($fecha_inicio <= $fecha_fin) {
            // Calcula el número de días entre las dos fechas
            $range = ((strtotime($fecha_fin) - strtotime($fecha_inicio)) + (24 * 60 * 60)) / (24 * 60 * 60);
            if ($range > 31) {
                // Muestra un mensaje de advertencia si el rango es mayor a 31 días
                echo "<p class='alert alert-warning'>El Rango Maximo es 31 Dias.</p>";
                exit(0);
            }
        } else {
            // Muestra un mensaje de error si el rango es inválido
            echo "<p class='alert alert-danger'>Rango Invalido</p>";
            exit(0);
        }

        // Incluye el archivo que define la clase Alumnos
        require_once "../modelos/Alumnos.php";
        // Crea una instancia de la clase Alumnos
        $alumnos = new Alumnos();
        // Verifica si hay alumnos en el grupo
        $rsptav = $alumnos->verficar_alumno($user_id, $team_id);

        if (!empty($rsptav)) {
            // Si hay alumnos, muestra una tabla de asistencia
            ?>

            <table id="dataw" class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Nombre</th>
                    <?php for ($i = 0; $i < $range; $i++) { ?>
                        <th>
                            <?php echo date("d-M", strtotime($fecha_inicio) + ($i * (24 * 60 * 60))); ?>
                        </th>
                    <?php } ?>
                </thead>
                <?php
                // Obtiene la lista de alumnos
                $rspta = $alumnos->listar_calif($user_id, $team_id);
                while ($reg = $rspta->fetch_object()) {
                    ?>
                    <tr>
                        <td style="width:250px;"><?php echo $reg->name . " " . $reg->lastname; ?></td>
                        <?php 
                        for ($i = 0; $i < $range; $i++) {
                            $date_at = date("Y-m-d", strtotime($fecha_inicio) + ($i * (24 * 60 * 60)));
                            // Obtiene la asistencia de cada alumno para la fecha actual
                            $asist = $consulta->listar_asistencia($reg->idalumn, $team_id, $date_at);
                            $regc = $asist->fetch_object();
                            ?> 
                            <td >
                            <?php
                            if ($regc != null) {
                                // Muestra el tipo de asistencia basado en el valor de kind_id
                                if ($regc->kind_id == 1) { echo "<strong>A</strong>"; }
                                else if ($regc->kind_id == 2) { echo "<strong>T</strong>"; }
                                else if ($regc->kind_id == 3) { echo "<strong>F</strong>"; }
                                else if ($regc->kind_id == 4) { echo "<strong>P</strong>"; }
                            }   
                            ?>
                            </td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </table>
            <?php
        } else {
            // Si no hay alumnos, muestra un mensaje de error
            echo "<p class='alert alert-danger'>No hay Alumnos</p>";
        }
        ?>

        <script type="text/javascript">         
            // Inicializa la tabla DataTables con botones para exportar
            tabla = $('#dataw').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdf'
                ]
            });
        </script>
        <?php
    break;

    case 'lista_comportamiento':
        // Recupera las fechas y el ID del grupo enviados mediante REQUEST
        $fecha_inicio = $_REQUEST["fecha_inicioc"];
        $fecha_fin = $_REQUEST["fecha_finc"];
        $team_id = $_REQUEST["idgrupo"];

        // Calcula el rango de fechas
        $range = 0;
        if ($fecha_inicio <= $fecha_fin) {
            $range = ((strtotime($fecha_fin) - strtotime($fecha_inicio)) + (24 * 60 * 60)) / (24 * 60 * 60);
            if ($range > 31) {
                // Muestra un mensaje de advertencia si el rango es mayor a 31 días
                echo "<p class='alert alert-warning'>El Rango Maximo es 31 Dias.</p>";
                exit(0);
            }
        } else {
            // Muestra un mensaje de error si el rango es inválido
            echo "<p class='alert alert-danger'>Rango Invalido</p>";
            exit(0);
        }

        // Incluye el archivo que define la clase Alumnos
        require_once "../modelos/Alumnos.php";
        // Crea una instancia de la clase Alumnos
        $alumnos = new Alumnos();
        // Verifica si hay alumnos en el grupo
        $rsptav = $alumnos->verficar_alumno($user_id, $team_id);

        if (!empty($rsptav)) {
            // Si hay alumnos, muestra una tabla de comportamiento
            ?>

            <table id="dataco" class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Nombre</th>
                    <?php for ($i = 0; $i < $range; $i++) { ?>
                        <th>
                            <?php echo date("d-M", strtotime($fecha_inicio) + ($i * (24 * 60 * 60))); ?>
                        </th>
                    <?php } ?>
                </thead>
                <?php
                // Obtiene la lista de alumnos
                $rspta = $alumnos->listar_calif($user_id, $team_id);
                while ($reg = $rspta->fetch_object()) {
                    ?>
                    <tr>
                        <td style="width:250px;"><?php echo $reg->name . " " . $reg->lastname; ?></td>
                        <?php 
                        for ($i = 0; $i < $range; $i++) {
                            $date_at = date("Y-m-d", strtotime($fecha_inicio) + ($i * (24 * 60 * 60)));
                            // Obtiene el comportamiento de cada alumno para la fecha actual
                            $asist = $consulta->listar_comportamiento($reg->idalumn, $team_id, $date_at);
                            $regc = $asist->fetch_object();
                            ?> 
                            <td >
                            <?php
                            if ($regc != null) {
                                // Muestra el tipo de comportamiento basado en el valor de kind_id
                                if ($regc->kind_id == 1) { echo "<strong>N</strong>"; }
                                else if ($regc->kind_id == 2) { echo "<strong>B</strong>"; }
                                else if ($regc->kind_id == 3) { echo "<strong>E</strong>"; }
                                else if ($regc->kind_id == 4) { echo "<strong>M</strong>"; }
                                else if ($regc->kind_id == 5) { echo "<strong>MM</strong>"; }
                            }   
                            ?>
                            </td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </table>
            <?php
        } else {
            // Si no hay alumnos, muestra un mensaje de error
            echo "<p class='alert alert-danger'>No hay Alumnos</p>";
        }
        ?>

        <script type="text/javascript">         
            // Inicializa la tabla DataTables con botones para exportar
            tabla = $('#dataco').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdf'
                ]
            });
        </script>
        <?php
    break;

    case 'listar_calificacion':
        // Incluye el archivo que define la clase Alumnos
        require_once "../modelos/Alumnos.php";
        // Crea una instancia de la clase Alumnos
        $alumnos = new Alumnos();
        $team_id = $_REQUEST["idgrupo"];
        // Verifica si hay alumnos en el grupo
        $rsptav = $alumnos->verficar_alumno($user_id, $team_id);

        // Incluye el archivo que define la clase Cursos
        require_once "../modelos/Cursos.php";
        // Crea una instancia de la clase Cursos
        $cursos = new Cursos();
        // Obtiene la lista de cursos para el grupo
        $rsptac = $cursos->listar($team_id);

        if (!empty($rsptav)) {
            // Si hay alumnos, muestra una tabla de calificaciones
            ?>

            <table id="dataca" class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Nombre</th>
                    <?php
                    // Muestra los nombres de los cursos en el encabezado de la tabla
                    while ($reg = $rsptac->fetch_object()) {
                        echo '<th>' . $reg->name . '</th>';
                    }
                    ?>
                </thead>
                <?php
                // Obtiene la lista de alumnos
                $rspta = $alumnos->listar_calif($user_id, $team_id);
                while ($reg = $rspta->fetch_object()) {
                    ?>
                    <tr>
                        <td><?php echo $reg->name . " " . $reg->lastname; ?></td>
                        <?php
                        // Para cada alumno, obtiene las calificaciones en los cursos
                        require_once "../modelos/Cursos.php";
                        $cursos = new Cursos();
                        $rsptacurso = $cursos->listar($team_id);
                        while ($regc = $rsptacurso->fetch_object()) {
                            $idcurso = $regc->id;
                            $idalumno = $reg->idalumn;

                            // Incluye el archivo que define la clase Calificaciones
                            require_once "../modelos/Calificaciones.php";
                            // Crea una instancia de la clase Calificaciones
                            $calificaciones = new Calificaciones();
                            // Obtiene la calificación del alumno para el curso actual
                            $rsptacalif = $calificaciones->listar_calificacion($idalumno, $idcurso);
                            $regn = $rsptacalif->fetch_object();
                            ?>
                            <td><?php if ($regn != null) { echo $regn->val; } ?></td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </table>
            <?php
        } else {
            // Si no hay alumnos, muestra un mensaje de error
            echo "<p class='alert alert-danger'>No hay Alumnos</p>";
        }
        ?>
        <script type="text/javascript">         
            // Inicializa la tabla DataTables con botones para exportar
            tabla = $('#dataca').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdf'
                ]
            });
        </script>
        <?php
    break;
}
?>