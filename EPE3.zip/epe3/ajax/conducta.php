<?php 
// Incluye el archivo que define la clase Conducta
require_once "../modelos/Conducta.php";

// Inicia una sesión si no ha sido iniciada
if (strlen(session_id()) < 1) 
    session_start(); 

// Crea una instancia de la clase Conducta
$conducta = new Conducta();

// Recupera y limpia los datos enviados mediante POST
$id = isset($_POST["idconducta"]) ? limpiarCadena($_POST["idconducta"]) : "";
$kind_id = isset($_POST["tipo_conducta"]) ? limpiarCadena($_POST["tipo_conducta"]) : "";
$date_at = isset($_POST["fecha_conducta"]) ? limpiarCadena($_POST["fecha_conducta"]) : "";
$alumn_id = isset($_POST["alumn_id"]) ? limpiarCadena($_POST["alumn_id"]) : "";
$team_id = isset($_POST["idgrupo"]) ? limpiarCadena($_POST["idgrupo"]) : "";
$user_id = $_SESSION["idusuario"];

// Maneja las diferentes operaciones según el parámetro 'op' enviado mediante GET
switch ($_GET["op"]) {
    case 'guardaryeditar':
        // Si el ID está vacío, se realiza una inserción; si no, se actualiza
        if (empty($id)) {
            // Llama al método insertar de la clase Conducta
            $rspta = $conducta->insertar($kind_id, $date_at, $alumn_id, $team_id); 
            // Devuelve un mensaje según el resultado de la inserción
            echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
        } else {
            // Llama al método editar de la clase Conducta
            $rspta = $conducta->editar($id, $kind_id, $date_at, $alumn_id, $team_id);
            // Devuelve un mensaje según el resultado de la actualización
            echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos"; 
        }
        break;
    
    case 'desactivar':
        // Llama al método desactivar de la clase Conducta
        $rspta = $conducta->desactivar($id);
        // Devuelve un mensaje según el resultado de la desactivación
        echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
        break;
    
    case 'activar':
        // Llama al método activar de la clase Conducta
        $rspta = $conducta->activar($id);
        // Devuelve un mensaje según el resultado de la activación
        echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
        break;
    
    case 'mostrar':
        // Llama al método mostrar de la clase Conducta y devuelve los datos en formato JSON
        $rspta = $conducta->mostrar($id);
        echo json_encode($rspta);
        break;
    
    case 'verificar':
        // Llama al método verificar de la clase Conducta y devuelve los datos en formato JSON
        $rspta = $conducta->verificar($date_at, $alumn_id, $team_id);
        echo json_encode($rspta);
        break;

    case 'listar':
        // Incluye el archivo que define la clase Alumnos
        require_once "../modelos/Alumnos.php";
        // Crea una instancia de la clase Alumnos
        $alumnos = new Alumnos();
        // Recupera el ID del grupo enviado mediante REQUEST
        $team_id = $_REQUEST["idgrupo"];
        // Llama al método listar de la clase Alumnos
        $rspta = $alumnos->listar($user_id, $team_id);
        $data = array();

        // Itera sobre los registros devueltos por el método listar
        while ($reg = $rspta->fetch_object()) {
            $data[] = array(
                // Agrega botones de acción dependiendo del estado del registro
                "0" => ($reg->is_active)
                    ? '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->id . ')"><i class="fa fa-pencil"></i></button>'
                      . ' ' . '<button class="btn btn-warning btn-xs" onclick="mostrar_precios(' . $reg->id . ')">P</i></button>'
                      . ' ' . '<button class="btn btn-danger btn-xs" onclick="desactivar(' . $reg->id . ')"><i class="fa fa-close"></i></button>'
                    : '<button class="btn btn-warning btn-xs" onclick="mostrar(' . $reg->id . ')"><i class="fa fa-pencil"></i></button>'
                      . '<button class="btn btn-warning btn-xs" onclick="mostrar_precios(' . $reg->id . ')">P</i></button>'
                      . ' ' . '<button class="btn btn-primary btn-xs" onclick="activar(' . $reg->id . ')"><i class="fa fa-check"></i></button>',
                // Muestra la imagen del alumno
                "1" => "<img src='../files/articulos/" . $reg->image . "' height='50px' width='50px'>",
                // Muestra el nombre del alumno
                "2" => $reg->name,
                // Muestra el apellido del alumno
                "3" => $reg->lastname,
                // Muestra el teléfono del alumno
                "4" => $reg->phone,
                // Muestra un botón para marcar al alumno
                "5" => '<button class="btn btn-info btn-xs" onclick="verificar(' . $reg->id . ')"><i class="fa fa-check"></i> Marcar</button>'
            );
        }

        // Prepara los datos para el datatable
        $results = array(
            "sEcho" => 1, // Información para datatables
            "iTotalRecords" => count($data), // Envia el total de registros al datatable
            "iTotalDisplayRecords" => count($data), // Envia el total de registros a visualizar
            "aaData" => $data // Datos para visualizar
        );

        // Devuelve los datos en formato JSON
        echo json_encode($results);
        break;
}
?>